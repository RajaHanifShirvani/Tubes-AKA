#ifndef HEADERAKA_H_INCLUDED
#define HEADERAKA_H_INCLUDED
#include <iostream>
using namespace std;

/* ===========================================|
||  ANGGOTA KELOMPOK:                        ||
||  1. Adi Bintang Syahputra (103012300499)  ||
||  2. Raja Hanif Shirvani (103012300315)    ||
|=========================================== */

int sequentialSearch(string arr[], int n, string target);           // algoritma iteratif
int binarySearch(string arr[], int left, int right, string target); // algoritma rekursif

#endif // HEADERAKA_H_INCLUDED
