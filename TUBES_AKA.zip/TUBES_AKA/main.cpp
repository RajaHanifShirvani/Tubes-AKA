#include "headerAKA.h"

/* ===========================================|
||  ANGGOTA KELOMPOK:                        ||
||  1. Adi Bintang Syahputra (103012300499)  ||
||  2. Raja Hanif Shirvani (103012300315)    ||
|=========================================== */

int main() {
    // ini placeholder inputnya, nah nanti dijadiin judul lagu paling, sama inputannya terurut
    string arr[] = {"a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"};
    int n = sizeof(arr) / sizeof(arr[0]);
    string target = "j"; // ini kata yang mau dicarinya

    // tinggal hapus komen didepannya kalo mau pake algoritma sequential atau binary:
    // int index = sequentialSearch(arr, n, target);
    int index = binarySearch(arr, 0, n-1, target);

    if (index != -1) {
        cout << "elemen ditemukan di index: " << index << endl;
    } else {
        cout << "elemen tidak ditemukan." << endl;
    }

    return 0;
}
